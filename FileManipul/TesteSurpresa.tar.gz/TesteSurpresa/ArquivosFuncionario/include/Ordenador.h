#include "Funcionario.h"
class Ordenador{
    public:
        void ordena(Funcionario *vetorFuncionario, int quantidade, bool crescente);

};