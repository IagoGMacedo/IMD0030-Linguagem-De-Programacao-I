Para executar, no diretório src, execute:

g++ main.cpp Funcionario.cpp  Ordenador.cpp  -o programa
./programa

